/**
 * 
 */
/**
 * @author Aluno
 *
 */
module JOGATINA {
	requires java.desktop;
}