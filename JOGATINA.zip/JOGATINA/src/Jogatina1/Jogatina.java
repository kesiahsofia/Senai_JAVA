package Jogatina1;

import java.util.Random;
import java.util.Scanner;
import java.text.DecimalFormat;
import javax.swing.JOptionPane;

public class Jogatina {

	

	/**
		 * @author Adilson Rodrigues Martins
		 * @author Kesiah Araujo Sofia
		 *
		 */
	
		public static void main(String[] args) {
			DecimalFormat convDecimal = new DecimalFormat("#,##0.00");
			Random sorteio = new Random();
			Scanner input = new Scanner(System.in);
			int nNumeros = 30;
			int premiado = sorteio.nextInt(nNumeros + 1);
			int escolhido;
			String posicao;
			int nTentativas = 5;
			int tentativa = 0;
			int tentativaRestante = 0;
			JOptionPane.showMessageDialog(null, "ACERTE O NÚMERO PREMIADO\n");
			String nome = JOptionPane.showInputDialog("Qual é o seu nome?");
			JOptionPane.showMessageDialog(null, "BEM VINDA(O) A JOGATINA, " + nome + "!");
			String vApostaS = JOptionPane.showInputDialog("Digite o valor de sua aposta: ");		
			float vAposta = Float.parseFloat(vApostaS);
			float vBanca = vAposta;
			float vMesa = vAposta + vBanca;
			JOptionPane.showMessageDialog(null, "A banca pagou sua aposta.\nTemos R$" + vMesa + " em jogo na mesa.\n");

			for (int i = 0; i < nTentativas; i++) {

				tentativa = tentativa + 1;
				tentativaRestante = 4 - i;

				double vMesaAtual;
				double vBancaAtual;
				vMesaAtual = vMesa - (vMesa * tentativa / 5.0);
				vBancaAtual = vMesa - vMesaAtual;

				String escolhidoS = JOptionPane.showInputDialog("\nDigite um valor entre 1 e " + nNumeros + ": ");		
				escolhido = Integer.parseInt(escolhidoS);
				
				if (escolhido > 0 && escolhido <= nNumeros) {

					if (escolhido == premiado) {
						if (tentativa > 1) {
							JOptionPane.showMessageDialog(null, "GANHOU! Você levou: R$" + convDecimal.format(vMesaAtual) + ".\n Você precisou de " + tentativa + " tentativas.");
							i = 10;
						} else {
							JOptionPane.showMessageDialog(null, "Ganhou! Você levou toda a mesa: R$" + convDecimal.format(vMesa) + ".\n Você precisou de " + tentativa + " tentativas.");
													i = 10;
						}

					}

					else {

						if (escolhido > premiado) {
							posicao = "maior";

						} else {
							posicao = "menor";
						}

						if (tentativaRestante >= 1) {

							if (tentativaRestante == 1) {
								JOptionPane.showMessageDialog(null, "Errou, você só tem mais uma chance!\n O valor atual da mesa é: R$" + convDecimal.format(vMesaAtual)+ "A banca ganhou: R$" + convDecimal.format(vBancaAtual) + ".\n");
								
							} else {
								JOptionPane.showMessageDialog(null, "Errou! Você tem mais " + tentativaRestante
										+ " tentativas.\nDica: seu número é " + posicao + " que o número premiado.\n O valor atual da mesa é: R$" + convDecimal.format(vMesaAtual) + ".\n A banca ganhou: R$" + convDecimal.format(vBancaAtual)+ ".");
								}

						} else {

							JOptionPane.showMessageDialog(null, "\n------------PERDEU!-------------\nNúmero premiado: " + premiado + ". \n A banca levou toda a mesa: R$" + convDecimal.format(vBancaAtual)+"." );
												}

					}

				} else {
					if (tentativaRestante > 1) {
						JOptionPane.showMessageDialog(null, "Digite um valor válido! Você tem mais " + tentativaRestante + " tentativas.\n");
					} else {
						JOptionPane.showMessageDialog(null, "NÃO digitou um valor válido! Acabaram as suas tentativas.\n");
					}

				}
			}
		}
}
